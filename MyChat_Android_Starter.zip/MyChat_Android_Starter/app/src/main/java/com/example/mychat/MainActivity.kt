package com.example.mychat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ChatGreen = Color(0xFF087F5B)
private val PaleGreen = Color(0xFFE8F5EF)

data class ChatPreview(val name: String, val message: String, val time: String, val initials: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyChatApp() }
    }
}

@Composable
fun MyChatApp() {
    var selectedTab by remember { mutableStateOf(0) }
    val chats = listOf(
        ChatPreview("Amit", "नमस्ते! कैसे हो?", "10:42", "A"),
        ChatPreview("Family Group", "आज शाम सब मिलते हैं", "09:18", "F"),
        ChatPreview("Priya", "फोटो भेज दी है", "कल", "P"),
        ChatPreview("Rahul", "ठीक है 👍", "कल", "R")
    )

    MaterialTheme(colorScheme = lightColorScheme(
        primary = ChatGreen,
        secondary = ChatGreen,
        background = Color(0xFFF7F9F8)
    )) {
        Scaffold(
            topBar = {
                Column(Modifier.fillMaxWidth().background(ChatGreen)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("MyChat", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("⋮", color = Color.White, fontSize = 28.sp)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        listOf("CHATS", "CALLS", "GROUPS").forEachIndexed { index, title ->
                            Column(
                                Modifier.clickable { selectedTab = index }.padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(5.dp))
                                if (selectedTab == index) Spacer(
                                    Modifier.width(58.dp).height(3.dp).background(Color.White, CircleShape)
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Chat, contentDescription = "Chats") },
                        label = { Text("चैट") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Call, contentDescription = "Calls") },
                        label = { Text("कॉल") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Groups, contentDescription = "Groups") },
                        label = { Text("ग्रुप") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("प्रोफाइल") }
                    )
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> ChatList(chats, Modifier.padding(padding))
                1 -> SimplePage("कॉल", "आपकी कॉल हिस्ट्री यहाँ दिखाई देगी।", Modifier.padding(padding))
                2 -> SimplePage("ग्रुप", "आपके ग्रुप यहाँ दिखाई देंगे।", Modifier.padding(padding))
                else -> SimplePage("प्रोफाइल", "आपकी प्रोफाइल यहाँ दिखाई देगी।", Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun ChatList(chats: List<ChatPreview>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().background(Color(0xFFF7F9F8))) {
        Text(
            "आपकी बातचीत",
            modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 8.dp),
            color = Color.DarkGray,
            fontWeight = FontWeight.SemiBold
        )
        LazyColumn {
            items(chats) { chat ->
                Row(
                    Modifier.fillMaxWidth().clickable { }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(50.dp).background(PaleGreen, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(chat.initials, color = ChatGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f).padding(start = 13.dp)) {
                        Text(chat.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(chat.message, color = Color.Gray, fontSize = 14.sp)
                    }
                    Text(chat.time, color = Color.Gray, fontSize = 12.sp)
                }
                HorizontalDivider(color = Color(0xFFECECEC), thickness = 0.7.dp)
            }
        }
    }
}

@Composable
fun SimplePage(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().background(Color(0xFFF7F9F8)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = ChatGreen)
        Spacer(Modifier.height(10.dp))
        Text(subtitle, color = Color.Gray)
    }
}
