MyChat Android Starter (प्रारंभिक स्क्रीन)

जरूरत:
- Android Studio (कोई हाल का stable संस्करण)
- Android SDK 35
- JDK 17

कैसे खोलें:
1. ZIP को extract करें।
2. Android Studio खोलें और 'Open' चुनें।
3. निकाला हुआ MyChat_Android_Starter फ़ोल्डर चुनें।
4. Gradle Sync पूरा होने दें।
5. Emulator या USB debugging वाले Android फोन पर Run दबाएँ।

ध्यान दें:
यह अभी UI starter है। इसमें वास्तविक लॉगिन, इंटरनेट मैसेजिंग, डेटाबेस,
कॉलिंग या end-to-end encryption अभी शामिल नहीं हैं। इन्हें अगले चरणों में
Firebase और WebRTC के साथ जोड़ा जाएगा।
